function loginUser(event) {
    event.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    if (username && password) {
        document.getElementById("loginPage").style.display = "none";
        document.getElementById("mainWebsite").style.display = "block";
        getNews();
    } else {
        alert("Please enter valid details");
    }
}
const API_KEY = "pub_bdeac15b6393490bb9414fbb874a63e2";
const newsContainer = document.getElementById("newsContainer");
const loader = document.getElementById("loader");
async function getNews(keyword = "") {
    let url = `https://newsdata.io/api/1/latest?apikey=${API_KEY}`;
    if (keyword !== "") {
        url += `&q=${keyword}`;
    }
    loader.style.display = "block";
    clearContainer();
    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.results) {
            displayNews(data.results);
        }
    } catch (error) {
        console.log("Error fetching news");
    }

    loader.style.display = "none";
}

function displayNews(articles) {
    clearContainer();
    articles.slice(0, 8).forEach(article => {
        const card = document.createElement("div");
        card.classList.add("news-card");
        const img = document.createElement("img");
        img.src = article.image_url ?
            article.image_url :
            "https://via.placeholder.com/400x200?text=No+Image";
        const content = document.createElement("div");
        content.classList.add("news-content");
        const title = document.createElement("h3");
        title.textContent = article.title;
        const desc = document.createElement("p");
        desc.textContent = article.description ?
            article.description.substring(0, 120) + "..." :
            "No description available.";
        const link = document.createElement("a");
        link.textContent = "Read Full Article →";
        link.href = article.link;
        link.target = "_blank";
        content.appendChild(title);
        content.appendChild(desc);
        content.appendChild(link);
        card.appendChild(img);
        card.appendChild(content);
        newsContainer.appendChild(card);
    });
}

function clearContainer() {
    while (newsContainer.firstChild) {
        newsContainer.removeChild(newsContainer.firstChild);
    }
}

function searchNews() {
    const keyword = document.getElementById("searchInput").value;
    getNews(keyword);
}
